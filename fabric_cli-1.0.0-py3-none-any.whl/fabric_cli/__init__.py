from .fabric_cli import * 

__author__ = """Viktor Gazdag"""
__email__ = 'viktor.gazdag@gmail.com'
__version__ = '1.0.0'